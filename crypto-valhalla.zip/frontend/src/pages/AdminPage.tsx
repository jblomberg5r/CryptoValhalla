export default function AdminPage() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Admin Page</h1>
      <p>This page is protected and will be used for admin functions.</p>
    </div>
  );
}