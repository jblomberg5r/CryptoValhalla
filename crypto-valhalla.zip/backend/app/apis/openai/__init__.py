
from fastapi import APIRouter
import databutton as db

# Router for endpoints
router = APIRouter()
