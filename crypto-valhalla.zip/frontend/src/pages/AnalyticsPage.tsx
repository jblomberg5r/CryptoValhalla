export default function AnalyticsPage() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Analytics Page</h1>
      <p>This page is protected and will display cryptocurrency analytics.</p>
    </div>
  );
}